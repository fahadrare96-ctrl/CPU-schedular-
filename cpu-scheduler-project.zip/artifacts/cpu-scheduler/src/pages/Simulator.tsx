import { useState, useCallback, useRef } from "react";

type Algorithm = "rr" | "fcfs" | "sjf" | "srtf" | "priority";

interface ProcessInput {
  name: string;
  burst: number;
  arrival: number;
  priority: number;
}

interface GanttSlot {
  process: string;
  start: number;
  end: number;
}

interface ProcessStats {
  name: string;
  burst: number;
  arrival: number;
  priority: number;
  completion: number;
  turnaround: number;
  waiting: number;
}

interface SimulationResult {
  algorithm: Algorithm;
  gantt: GanttSlot[];
  stats: ProcessStats[];
  metrics: {
    totalTime: number;
    avgWaiting: number;
    avgTurnaround: number;
    cpuUtilization: number;
  };
}

const COLORS = [
  { bg: "bg-violet-500", text: "text-white", light: "bg-violet-100 text-violet-700" },
  { bg: "bg-sky-500",    text: "text-white", light: "bg-sky-100 text-sky-700" },
  { bg: "bg-emerald-500",text: "text-white", light: "bg-emerald-100 text-emerald-700" },
  { bg: "bg-amber-500",  text: "text-white", light: "bg-amber-100 text-amber-700" },
  { bg: "bg-rose-500",   text: "text-white", light: "bg-rose-100 text-rose-700" },
  { bg: "bg-teal-500",   text: "text-white", light: "bg-teal-100 text-teal-700" },
  { bg: "bg-orange-500", text: "text-white", light: "bg-orange-100 text-orange-700" },
  { bg: "bg-pink-500",   text: "text-white", light: "bg-pink-100 text-pink-700" },
];

function getColor(index: number) {
  return COLORS[index % COLORS.length];
}

const DEFAULT_PROCESSES: ProcessInput[] = [
  { name: "P1", burst: 5, arrival: 0, priority: 2 },
  { name: "P2", burst: 3, arrival: 1, priority: 1 },
  { name: "P3", burst: 7, arrival: 2, priority: 3 },
  { name: "P4", burst: 2, arrival: 3, priority: 2 },
];

const algorithmLabel: Record<Algorithm, string> = {
  rr:       "Round Robin",
  fcfs:     "First Come First Served",
  sjf:      "Shortest Job First",
  srtf:     "Shortest Remaining Time First",
  priority: "Priority Scheduling",
};

const algorithmDesc: Record<Algorithm, string> = {
  rr:       "Each process gets a fixed time slice (quantum), cycling until complete.",
  fcfs:     "Processes execute in order of arrival. Simple and fair.",
  sjf:      "Picks the shortest available burst each time. Minimises average wait.",
  srtf:     "Preemptive SJF — new arrivals can interrupt the running process.",
  priority: "Picks the highest-priority (lowest number) available process. Non-preemptive.",
};

export default function Simulator() {
  const [processes, setProcesses]   = useState<ProcessInput[]>(DEFAULT_PROCESSES);
  const [algorithm, setAlgorithm]   = useState<Algorithm>("rr");
  const [quantum, setQuantum]       = useState(2);
  const [result, setResult]         = useState<SimulationResult | null>(null);
  const [loading, setLoading]       = useState(false);
  const [error, setError]           = useState("");
  const abortRef                    = useRef<AbortController | null>(null);

  const showPriority = algorithm === "priority";

  const colorMap = useCallback((name: string) => {
    const idx = processes.findIndex((p) => p.name === name);
    return getColor(idx >= 0 ? idx : 0);
  }, [processes]);

  const addProcess = () => {
    const n = processes.length + 1;
    setProcesses([...processes, {
      name: `P${n}`,
      burst: Math.floor(Math.random() * 8) + 1,
      arrival: n - 1,
      priority: Math.floor(Math.random() * 5) + 1,
    }]);
    setResult(null);
  };

  const removeProcess = (i: number) => {
    setProcesses(processes.filter((_, idx) => idx !== i));
    setResult(null);
  };

  const updateProcess = (i: number, field: keyof ProcessInput, value: string) => {
    const updated = [...processes];
    if (field === "name") {
      updated[i] = { ...updated[i], name: value };
    } else {
      const num = parseInt(value, 10);
      updated[i] = { ...updated[i], [field]: isNaN(num) ? 0 : Math.max(field === "burst" ? 1 : 0, num) };
    }
    setProcesses(updated);
    setResult(null);
  };

  const simulate = async () => {
    setError("");

    // Client-side validation
    if (processes.length === 0) { setError("Add at least one process."); return; }
    for (const p of processes) {
      if (!p.name.trim())  { setError("All processes need a name."); return; }
      if (p.burst <= 0)    { setError(`${p.name}: Burst time must be > 0.`); return; }
      if (showPriority && p.priority < 1) { setError(`${p.name}: Priority must be ≥ 1.`); return; }
    }

    // Cancel any in-flight request
    abortRef.current?.abort();
    abortRef.current = new AbortController();

    setLoading(true);
    try {
      const res = await fetch("/api/simulate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ algorithm, processes, quantum }),
        signal: abortRef.current.signal,
      });

      if (!res.ok) {
        const body = await res.json().catch(() => ({}));
        throw new Error(body.error ?? `Server error ${res.status}`);
      }

      const data: SimulationResult = await res.json();
      setResult(data);
    } catch (err: unknown) {
      if (err instanceof Error && err.name === "AbortError") return;
      setError(err instanceof Error ? err.message : "Unexpected error. Is the API server running?");
    } finally {
      setLoading(false);
    }
  };

  const { totalTime, avgWaiting, avgTurnaround, cpuUtilization } = result?.metrics ?? {
    totalTime: 0, avgWaiting: 0, avgTurnaround: 0, cpuUtilization: 0,
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card shadow-sm">
        <div className="max-w-6xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <svg className="w-4 h-4 text-primary-foreground" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 3H5a2 2 0 00-2 2v4m6-6h10a2 2 0 012 2v4M9 3v18m0 0h10a2 2 0 002-2V9M9 21H5a2 2 0 01-2-2V9m0 0h18" />
              </svg>
            </div>
            <div>
              <h1 className="text-lg font-semibold text-foreground">CPU Scheduling Simulator</h1>
              <p className="text-xs text-muted-foreground">Visualize process scheduling algorithms</p>
            </div>
          </div>
          {/* API status badge */}
          <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-secondary px-3 py-1.5 rounded-full">
            <span className={`w-1.5 h-1.5 rounded-full ${loading ? "bg-amber-400 animate-pulse" : "bg-emerald-400"}`} />
            {loading ? "Computing…" : "API Ready"}
          </div>
        </div>
      </header>

      <div className="max-w-6xl mx-auto px-6 py-8 space-y-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">

          {/* ── Left Panel: Algorithm + Controls ── */}
          <div className="lg:col-span-1 space-y-5">
            <div className="bg-card border rounded-xl p-5 shadow-sm">
              <h2 className="text-sm font-semibold text-foreground mb-3">Algorithm</h2>
              <div className="grid grid-cols-1 gap-2">
                {(["rr","fcfs","sjf","srtf","priority"] as Algorithm[]).map((alg) => (
                  <button
                    key={alg}
                    onClick={() => { setAlgorithm(alg); setResult(null); }}
                    className={`text-left px-3 py-2.5 rounded-lg text-sm font-medium transition-all ${
                      algorithm === alg
                        ? "bg-primary text-primary-foreground shadow-sm"
                        : "bg-secondary text-secondary-foreground hover:bg-accent"
                    }`}
                  >
                    {algorithmLabel[alg]}
                  </button>
                ))}
              </div>

              <p className="mt-4 pt-4 border-t text-xs text-muted-foreground leading-relaxed">
                {algorithmDesc[algorithm]}
              </p>

              {algorithm === "rr" && (
                <div className="mt-4 pt-4 border-t">
                  <label className="text-xs font-medium text-muted-foreground block mb-1.5">Time Quantum</label>
                  <div className="flex items-center gap-2">
                    <button onClick={() => setQuantum(Math.max(1, quantum - 1))}
                      className="w-8 h-8 rounded-lg bg-secondary hover:bg-accent text-secondary-foreground font-bold flex items-center justify-center">−</button>
                    <span className="flex-1 text-center font-semibold text-foreground text-lg">{quantum}</span>
                    <button onClick={() => setQuantum(quantum + 1)}
                      className="w-8 h-8 rounded-lg bg-secondary hover:bg-accent text-secondary-foreground font-bold flex items-center justify-center">+</button>
                  </div>
                </div>
              )}

              {showPriority && (
                <div className="mt-4 pt-4 border-t">
                  <p className="text-xs font-medium text-muted-foreground mb-2">Priority Guide</p>
                  <div className="space-y-1">
                    {[{p:1,label:"Highest priority"},{p:2,label:"High"},{p:3,label:"Medium"},{p:4,label:"Low"},{p:5,label:"Lowest priority"}].map(({p,label}) => (
                      <div key={p} className="flex items-center gap-2 text-xs">
                        <span className="w-5 h-5 rounded bg-primary/10 text-primary font-bold flex items-center justify-center text-[10px]">{p}</span>
                        <span className="text-muted-foreground">{label}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <button
              onClick={simulate}
              disabled={loading}
              className="w-full py-3 bg-primary text-primary-foreground rounded-xl font-semibold text-sm hover:opacity-90 disabled:opacity-60 transition-all shadow-sm active:scale-95 flex items-center justify-center gap-2"
            >
              {loading ? (
                <>
                  <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"/>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8z"/>
                  </svg>
                  Running…
                </>
              ) : "Run Simulation"}
            </button>

            {error && (
              <div className="bg-destructive/10 border border-destructive/30 text-destructive text-sm rounded-lg px-4 py-3 flex items-start gap-2">
                <svg className="w-4 h-4 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                </svg>
                {error}
              </div>
            )}
          </div>

          {/* ── Right Panel: Process Table ── */}
          <div className="lg:col-span-2 bg-card border rounded-xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h2 className="text-sm font-semibold text-foreground">Processes</h2>
                {showPriority && (
                  <p className="text-xs text-muted-foreground mt-0.5">Lower priority number = runs first</p>
                )}
              </div>
              <button
                onClick={addProcess}
                className="flex items-center gap-1.5 text-xs font-medium text-primary hover:text-primary/80 bg-accent px-3 py-1.5 rounded-lg transition-colors"
              >
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4"/>
                </svg>
                Add Process
              </button>
            </div>

            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b text-xs text-muted-foreground">
                    <th className="text-left pb-2 pr-3 font-medium">Process</th>
                    <th className="text-left pb-2 pr-3 font-medium">Burst Time</th>
                    <th className="text-left pb-2 pr-3 font-medium">Arrival Time</th>
                    {showPriority && (
                      <th className="text-left pb-2 pr-3 font-medium">
                        <span className="flex items-center gap-1">
                          Priority
                          <span className="text-[10px] bg-primary/10 text-primary rounded px-1 py-0.5 font-normal">1=highest</span>
                        </span>
                      </th>
                    )}
                    <th className="pb-2 w-8" />
                  </tr>
                </thead>
                <tbody className="divide-y divide-border">
                  {processes.map((p, i) => {
                    const color = getColor(i);
                    return (
                      <tr key={i} className="group">
                        <td className="py-2 pr-3">
                          <div className="flex items-center gap-2">
                            <div className={`w-2.5 h-2.5 rounded-full flex-shrink-0 ${color.bg}`} />
                            <input
                              value={p.name}
                              onChange={(e) => updateProcess(i, "name", e.target.value)}
                              className="w-14 text-sm font-medium bg-transparent border border-transparent focus:border-border rounded px-1 py-0.5 outline-none focus:bg-background transition-colors"
                            />
                          </div>
                        </td>
                        <td className="py-2 pr-3">
                          <input type="number" min="1" value={p.burst}
                            onChange={(e) => updateProcess(i, "burst", e.target.value)}
                            className="w-16 text-sm bg-secondary border border-transparent focus:border-border rounded-lg px-2 py-1 outline-none focus:bg-background transition-colors"
                          />
                        </td>
                        <td className="py-2 pr-3">
                          <input type="number" min="0" value={p.arrival}
                            onChange={(e) => updateProcess(i, "arrival", e.target.value)}
                            className="w-16 text-sm bg-secondary border border-transparent focus:border-border rounded-lg px-2 py-1 outline-none focus:bg-background transition-colors"
                          />
                        </td>
                        {showPriority && (
                          <td className="py-2 pr-3">
                            <input type="number" min="1" value={p.priority}
                              onChange={(e) => updateProcess(i, "priority", e.target.value)}
                              className="w-16 text-sm bg-primary/10 border border-primary/20 focus:border-primary rounded-lg px-2 py-1 outline-none focus:bg-background transition-colors font-semibold text-primary"
                            />
                          </td>
                        )}
                        <td className="py-2">
                          <button
                            onClick={() => removeProcess(i)}
                            className="opacity-0 group-hover:opacity-100 w-7 h-7 flex items-center justify-center rounded-lg text-muted-foreground hover:text-destructive hover:bg-destructive/10 transition-all"
                          >
                            <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/>
                            </svg>
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* ── Results ── */}
        {result && (
          <div className="space-y-5">

            {/* Metric Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                { label: "Total Time",       value: `${totalTime} units` },
                { label: "CPU Utilization",  value: `${cpuUtilization}%` },
                { label: "Avg Waiting",      value: `${avgWaiting} units` },
                { label: "Avg Turnaround",   value: `${avgTurnaround} units` },
              ].map((s) => (
                <div key={s.label} className="bg-card border rounded-xl p-4 shadow-sm">
                  <p className="text-xs text-muted-foreground font-medium">{s.label}</p>
                  <p className="text-xl font-bold text-foreground mt-1">{s.value}</p>
                </div>
              ))}
            </div>

            {/* Gantt Chart */}
            <div className="bg-card border rounded-xl p-5 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-sm font-semibold text-foreground">
                  Gantt Chart — {algorithmLabel[result.algorithm]}
                </h2>
                <span className="text-xs text-muted-foreground bg-secondary px-2 py-1 rounded-md">
                  {result.gantt.length} slot{result.gantt.length !== 1 ? "s" : ""}
                </span>
              </div>

              <div className="overflow-x-auto">
                <div className="min-w-max">
                  <div className="flex rounded-lg overflow-hidden border border-border">
                    {result.gantt.map((slot, i) => {
                      const width = ((slot.end - slot.start) / totalTime) * 100;
                      const color = colorMap(slot.process);
                      const prio  = processes.find((p) => p.name === slot.process)?.priority;
                      return (
                        <div
                          key={i}
                          className={`${color.bg} ${color.text} relative group`}
                          style={{ width: `${Math.max(width, 3)}%`, minWidth: "40px" }}
                        >
                          <div className="h-14 flex flex-col items-center justify-center text-xs font-semibold border-r border-white/20 gap-0.5 px-1">
                            <span>{slot.process}</span>
                            {showPriority && prio !== undefined && (
                              <span className="text-[10px] opacity-70">P{prio}</span>
                            )}
                          </div>
                          {/* Hover tooltip */}
                          <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 bg-foreground text-background text-xs rounded-lg px-2.5 py-1.5 whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 shadow-lg">
                            <div className="font-semibold">{slot.process}</div>
                            <div className="opacity-70">{slot.start} → {slot.end} · {slot.end - slot.start} unit{slot.end - slot.start !== 1 ? "s" : ""}</div>
                            {showPriority && prio !== undefined && <div className="opacity-70">Priority: {prio}</div>}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                  {/* Time axis */}
                  <div className="flex mt-1.5 px-0">
                    {result.gantt.map((slot, i) => {
                      const width = ((slot.end - slot.start) / totalTime) * 100;
                      return (
                        <div key={i} className="relative text-xs text-muted-foreground"
                          style={{ width: `${Math.max(width, 3)}%`, minWidth: "40px" }}>
                          <span className="absolute left-0 -translate-x-1/2">{slot.start}</span>
                          {i === result.gantt.length - 1 && (
                            <span className="absolute right-0 translate-x-1/2">{slot.end}</span>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Legend */}
              <div className="flex flex-wrap gap-3 mt-5 pt-4 border-t">
                {processes.map((p, i) => {
                  const color = getColor(i);
                  return (
                    <div key={p.name} className="flex items-center gap-1.5">
                      <div className={`w-3 h-3 rounded-sm ${color.bg}`} />
                      <span className="text-xs text-muted-foreground font-medium">
                        {p.name}{showPriority && <span className="ml-1 opacity-60">(P{p.priority})</span>}
                      </span>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Stats Table */}
            <div className="bg-card border rounded-xl p-5 shadow-sm">
              <h2 className="text-sm font-semibold text-foreground mb-4">Process Statistics</h2>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b text-xs text-muted-foreground">
                      <th className="text-left pb-2 pr-4 font-medium">Process</th>
                      <th className="text-right pb-2 pr-4 font-medium">Arrival</th>
                      <th className="text-right pb-2 pr-4 font-medium">Burst</th>
                      {showPriority && <th className="text-right pb-2 pr-4 font-medium text-primary">Priority</th>}
                      <th className="text-right pb-2 pr-4 font-medium">Completion</th>
                      <th className="text-right pb-2 pr-4 font-medium">Turnaround</th>
                      <th className="text-right pb-2 font-medium">Waiting</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-border">
                    {result.stats
                      .slice()
                      .sort((a, b) =>
                        showPriority
                          ? a.priority - b.priority
                          : processes.findIndex(p => p.name === a.name) - processes.findIndex(p => p.name === b.name)
                      )
                      .map((s) => {
                        const color = getColor(processes.findIndex((p) => p.name === s.name));
                        return (
                          <tr key={s.name} className="hover:bg-muted/40 transition-colors">
                            <td className="py-2.5 pr-4">
                              <div className="flex items-center gap-2">
                                <div className={`w-2.5 h-2.5 rounded-full ${color.bg}`} />
                                <span className="font-medium text-foreground">{s.name}</span>
                              </div>
                            </td>
                            <td className="py-2.5 pr-4 text-right text-muted-foreground">{s.arrival}</td>
                            <td className="py-2.5 pr-4 text-right text-muted-foreground">{s.burst}</td>
                            {showPriority && (
                              <td className="py-2.5 pr-4 text-right">
                                <span className="inline-block px-2 py-0.5 rounded-md text-xs font-bold bg-primary/10 text-primary">{s.priority}</span>
                              </td>
                            )}
                            <td className="py-2.5 pr-4 text-right text-foreground font-medium">{s.completion}</td>
                            <td className="py-2.5 pr-4 text-right">
                              <span className={`inline-block px-2 py-0.5 rounded-md text-xs font-medium ${color.light}`}>{s.turnaround}</span>
                            </td>
                            <td className="py-2.5 text-right">
                              <span className="inline-block px-2 py-0.5 rounded-md text-xs font-medium bg-muted text-muted-foreground">{s.waiting}</span>
                            </td>
                          </tr>
                        );
                      })
                    }
                    {/* Averages row */}
                    <tr className="bg-muted/30 font-semibold text-sm">
                      <td className="py-2.5 pr-4 text-muted-foreground" colSpan={showPriority ? 5 : 4}>Average</td>
                      <td className="py-2.5 pr-4 text-right text-foreground">{avgTurnaround}</td>
                      <td className="py-2.5 text-right text-foreground">{avgWaiting}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>

          </div>
        )}
      </div>
    </div>
  );
}
