import { Router, type IRouter } from "express";
import { z } from "zod";

const router: IRouter = Router();

const ProcessSchema = z.object({
  name: z.string().min(1),
  burst: z.number().int().min(1),
  arrival: z.number().int().min(0),
  priority: z.number().int().min(1).default(1),
});

const SimulateRequestSchema = z.object({
  algorithm: z.enum(["rr", "fcfs", "sjf", "srtf", "priority"]),
  processes: z.array(ProcessSchema).min(1),
  quantum: z.number().int().min(1).optional().default(2),
});

type Process = z.infer<typeof ProcessSchema>;

interface GanttSlot {
  process: string;
  start: number;
  end: number;
}

interface ProcessStats {
  name: string;
  burst: number;
  arrival: number;
  priority: number;
  completion: number;
  turnaround: number;
  waiting: number;
}

function simulateRR(processes: Process[], quantum: number) {
  const procs = processes.map((p) => ({ ...p, remaining: p.burst }));
  const gantt: GanttSlot[] = [];
  const completion: Record<string, number> = {};
  let time = 0;
  const queue: typeof procs = [];
  const arrived = new Set<string>();
  const sorted = [...procs].sort((a, b) => a.arrival - b.arrival);

  while (true) {
    for (const p of sorted) {
      if (p.arrival <= time && !arrived.has(p.name) && p.remaining > 0) {
        arrived.add(p.name);
        queue.push(p);
      }
    }
    if (queue.length === 0) {
      const next = sorted.find((p) => p.remaining > 0);
      if (!next) break;
      time = next.arrival;
      arrived.add(next.name);
      queue.push(next);
    }
    const proc = queue.shift()!;
    const exec = Math.min(proc.remaining, quantum);
    gantt.push({ process: proc.name, start: time, end: time + exec });
    time += exec;
    proc.remaining -= exec;
    for (const p of sorted) {
      if (p.arrival <= time && !arrived.has(p.name) && p.remaining > 0) {
        arrived.add(p.name);
        queue.push(p);
      }
    }
    if (proc.remaining > 0) {
      queue.push(proc);
    } else {
      completion[proc.name] = time;
    }
  }

  return { gantt, completion };
}

function simulateFCFS(processes: Process[]) {
  const sorted = [...processes].sort((a, b) => a.arrival - b.arrival);
  const gantt: GanttSlot[] = [];
  const completion: Record<string, number> = {};
  let time = 0;
  for (const p of sorted) {
    if (time < p.arrival) time = p.arrival;
    gantt.push({ process: p.name, start: time, end: time + p.burst });
    time += p.burst;
    completion[p.name] = time;
  }
  return { gantt, completion };
}

function simulateSJF(processes: Process[]) {
  const procs = processes.map((p) => ({ ...p, done: false }));
  const gantt: GanttSlot[] = [];
  const completion: Record<string, number> = {};
  let time = 0;
  while (procs.some((p) => !p.done)) {
    const available = procs.filter((p) => !p.done && p.arrival <= time);
    if (available.length === 0) {
      time = Math.min(...procs.filter((p) => !p.done).map((p) => p.arrival));
      continue;
    }
    available.sort((a, b) => a.burst - b.burst);
    const proc = available[0];
    gantt.push({ process: proc.name, start: time, end: time + proc.burst });
    time += proc.burst;
    completion[proc.name] = time;
    procs.find((p) => p.name === proc.name)!.done = true;
  }
  return { gantt, completion };
}

function simulateSRTF(processes: Process[]) {
  const procs = processes.map((p) => ({ ...p, remaining: p.burst }));
  const gantt: GanttSlot[] = [];
  const completion: Record<string, number> = {};
  let time = 0;
  const totalBurst = procs.reduce((s, p) => s + p.burst, 0);
  const maxTime = Math.max(...procs.map((p) => p.arrival)) + totalBurst + 1;
  let last = "";
  while (time <= maxTime && procs.some((p) => p.remaining > 0)) {
    const available = procs.filter((p) => p.remaining > 0 && p.arrival <= time);
    if (available.length === 0) { time++; continue; }
    available.sort((a, b) => a.remaining - b.remaining);
    const proc = available[0];
    if (last !== proc.name) {
      gantt.push({ process: proc.name, start: time, end: time + 1 });
      last = proc.name;
    } else {
      gantt[gantt.length - 1].end++;
    }
    proc.remaining--;
    time++;
    if (proc.remaining === 0) completion[proc.name] = time;
  }
  return { gantt, completion };
}

function simulatePriority(processes: Process[]) {
  const procs = processes.map((p) => ({ ...p, done: false }));
  const gantt: GanttSlot[] = [];
  const completion: Record<string, number> = {};
  let time = 0;
  while (procs.some((p) => !p.done)) {
    const available = procs.filter((p) => !p.done && p.arrival <= time);
    if (available.length === 0) {
      const nextArrival = Math.min(...procs.filter((p) => !p.done).map((p) => p.arrival));
      time = nextArrival;
      continue;
    }
    available.sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      if (a.arrival !== b.arrival) return a.arrival - b.arrival;
      return a.name.localeCompare(b.name);
    });
    const proc = available[0];
    gantt.push({ process: proc.name, start: time, end: time + proc.burst });
    time += proc.burst;
    completion[proc.name] = time;
    procs.find((p) => p.name === proc.name)!.done = true;
  }
  return { gantt, completion };
}

function buildStats(processes: Process[], completion: Record<string, number>): ProcessStats[] {
  return processes.map((p) => ({
    name: p.name,
    burst: p.burst,
    arrival: p.arrival,
    priority: p.priority,
    completion: completion[p.name] ?? 0,
    turnaround: (completion[p.name] ?? 0) - p.arrival,
    waiting: (completion[p.name] ?? 0) - p.arrival - p.burst,
  }));
}

router.post("/simulate", (req, res) => {
  const parsed = SimulateRequestSchema.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Invalid input", details: parsed.error.issues });
    return;
  }

  const { algorithm, processes, quantum } = parsed.data;

  let gantt: GanttSlot[];
  let completion: Record<string, number>;

  switch (algorithm) {
    case "rr":
      ({ gantt, completion } = simulateRR(processes, quantum));
      break;
    case "fcfs":
      ({ gantt, completion } = simulateFCFS(processes));
      break;
    case "sjf":
      ({ gantt, completion } = simulateSJF(processes));
      break;
    case "srtf":
      ({ gantt, completion } = simulateSRTF(processes));
      break;
    case "priority":
      ({ gantt, completion } = simulatePriority(processes));
      break;
  }

  const stats = buildStats(processes, completion);

  const totalTime = gantt.length > 0 ? Math.max(...gantt.map((g) => g.end)) : 0;
  const totalBurst = processes.reduce((s, p) => s + p.burst, 0);
  const avgWaiting = stats.reduce((s, p) => s + p.waiting, 0) / stats.length;
  const avgTurnaround = stats.reduce((s, p) => s + p.turnaround, 0) / stats.length;
  const cpuUtilization = totalTime > 0 ? (totalBurst / totalTime) * 100 : 0;

  res.json({
    algorithm,
    gantt,
    stats,
    metrics: {
      totalTime,
      avgWaiting: Math.round(avgWaiting * 100) / 100,
      avgTurnaround: Math.round(avgTurnaround * 100) / 100,
      cpuUtilization: Math.round(cpuUtilization * 10) / 10,
    },
  });
});

export default router;
